# imli > 2024-07-01 6:18am
https://universe.roboflow.com/datasetish/imli

Provided by a Roboflow user
License: CC BY 4.0

